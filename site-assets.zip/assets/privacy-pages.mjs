const pages = [...document.querySelectorAll('.privacy-page')];
let current = 0;
function show() {
  pages.forEach((page, index) => { page.hidden = index !== current; });
  document.getElementById('privacy-prev').disabled = current === 0;
  document.getElementById('privacy-next').disabled = current === pages.length - 1;
  document.getElementById('privacy-position').textContent = `${current + 1} / ${pages.length}`;
}
document.getElementById('privacy-prev').addEventListener('click', () => { current--; show(); });
document.getElementById('privacy-next').addEventListener('click', () => { current++; show(); });
show();
