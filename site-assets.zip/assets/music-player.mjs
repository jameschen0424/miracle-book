export const TRACKS = Object.freeze([
  { id: 'shanshui', title: '山水清音', subtitle: '山水之間，靜聽心聲', src: 'assets/music/shanshui.mp3' },
  { id: 'cello', title: 'Cello Reflections', subtitle: '大提琴沉思', src: 'assets/music/cello-reflections.mp3' },
  { id: 'forest', title: 'Forest Morning', subtitle: '森林晨光', src: 'assets/music/forest-morning.mp3' },
  { id: 'drift', title: 'Weightless Drift', subtitle: '輕盈漂流', src: 'assets/music/weightless-drift.mp3' },
  { id: 'untitled', title: 'Untitled', subtitle: '純音樂', src: 'assets/music/untitled.mp3' },
].map(track => Object.freeze(track)));

export class BackgroundMusic {
  #audio; #onChange; #state; #token = 0; #destroyed = false; #intentPlaying = false; #listeners = [];

  constructor({ audio, trackId = 'shanshui', volume = .35, mode = 'all', onChange = () => {} } = {}) {
    this.#audio = audio ?? new globalThis.Audio();
    this.#onChange = onChange;
    const track = TRACKS.find(item => item.id === trackId) ?? TRACKS[0];
    this.#state = { trackId: track.id, volume: .35, mode: mode === 'single' ? 'single' : 'all', playing: false, loading: false, error: null, currentTime: 0, duration: 0 };
    this.#audio.preload = 'none';
    this.#audio.loop = false;
    this.#audio.src = track.src;
    this.setVolume(volume);
    const listen = (name, callback) => {
      this.#audio.addEventListener(name, callback);
      this.#listeners.push([name, callback]);
    };
    listen('playing', () => { if (!this.#audio.paused) this.#update({ playing: true, loading: false, error: null }); });
    listen('pause', () => {
      if (this.#audio.paused) {
        if (!this.#state.loading && !this.#audio.ended) this.#intentPlaying = false;
        this.#update({ playing: false });
      }
    });
    listen('waiting', () => { if (this.#intentPlaying) this.#update({ loading: true }); });
    for (const event of ['timeupdate', 'durationchange', 'loadedmetadata']) listen(event, () => this.#update({
      currentTime: Number.isFinite(this.#audio.currentTime) ? this.#audio.currentTime : 0,
      duration: Number.isFinite(this.#audio.duration) ? this.#audio.duration : 0,
    }));
    listen('error', () => {
      this.#token++;
      this.#intentPlaying = false;
      this.#update({ playing: false, loading: false, error: '背景音樂暫時無法播放，請輕點音樂開關重試。' });
    });
    listen('ended', () => {
      if (!this.#intentPlaying) return;
      if (this.#state.mode === 'single') {
        this.#audio.currentTime = 0;
        void this.play();
      } else {
        const index = TRACKS.findIndex(item => item.id === this.#state.trackId);
        void this.select(TRACKS[(index + 1) % TRACKS.length].id, { play: true });
      }
    });
  }

  get state() { return { ...this.#state }; }
  #update(change) {
    if (this.#destroyed) return;
    Object.assign(this.#state, change);
    this.#onChange(this.state);
  }

  async play() {
    if (this.#destroyed) return;
    const token = ++this.#token;
    this.#intentPlaying = true;
    this.#update({ loading: true, error: null });
    try {
      await this.#audio.play();
      if (token !== this.#token || this.#destroyed) return;
      this.#intentPlaying = !this.#audio.paused;
      this.#update({ playing: !this.#audio.paused, loading: false, error: null });
    } catch (error) {
      if (token !== this.#token || this.#destroyed) return;
      this.#intentPlaying = false;
      this.#update({ playing: false, loading: false, error: error?.name === 'AbortError' ? null : '背景音樂暫時無法播放，請輕點音樂開關重試。' });
    }
  }

  pause() {
    if (this.#destroyed) return;
    this.#token++;
    this.#intentPlaying = false;
    this.#audio.pause();
    this.#update({ playing: false, loading: false });
  }

  async select(id, { play = false } = {}) {
    if (this.#destroyed) return;
    const track = TRACKS.find(item => item.id === id);
    if (!track) { this.#update({ error: '找不到這首音樂。' }); return; }
    this.pause();
    this.#audio.src = track.src;
    this.#update({ trackId: id, currentTime: 0, duration: 0, loading: false, error: null });
    if (play) await this.play();
  }

  async #step(offset) {
    const play = this.#state.playing || this.#intentPlaying;
    const index = TRACKS.findIndex(item => item.id === this.#state.trackId);
    await this.select(TRACKS[(index + offset + TRACKS.length) % TRACKS.length].id, { play });
  }
  async next() { await this.#step(1); }
  async previous() { await this.#step(-1); }

  setVolume(volume) {
    if (this.#destroyed || !Number.isFinite(volume)) return;
    const normalized = Math.max(0, Math.min(1, volume));
    this.#audio.volume = normalized;
    this.#update({ volume: normalized });
  }
  setMode(mode) { if (mode === 'all' || mode === 'single') this.#update({ mode }); }

  destroy() {
    if (this.#destroyed) return;
    this.pause();
    for (const [name, callback] of this.#listeners) this.#audio.removeEventListener(name, callback);
    this.#destroyed = true;
    this.#audio.removeAttribute?.('src');
    this.#onChange = () => {};
  }
}
