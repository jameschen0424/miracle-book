/** Short, interruptible feedback. Animation never owns application state. */
export class MotionDirector {
  constructor(enabled) { this.enabled = enabled; this.active = new Map(); }

  play(element, frames, { name = 'reveal', duration = 280, delay = 0, easing = 'cubic-bezier(.2,.7,.2,1)' } = {}) {
    if (!element) return null;
    this.cancel(element);
    if (!this.enabled() || typeof element.animate !== 'function') return null;
    const animation = element.animate(frames, { duration, delay, easing, fill: 'none' });
    element.dataset.motion = name;
    this.active.set(element, animation);
    const release = () => {
      if (this.active.get(element) !== animation) return;
      this.active.delete(element); delete element.dataset.motion;
    };
    // Cancellation is normal when navigation, reduced motion or backgrounding interrupts.
    animation.finished.then(release, release);
    return animation;
  }

  cancel(element) {
    this.active.get(element)?.cancel();
    this.active.delete(element);
    if (element) delete element.dataset.motion;
  }

  cancelWithin(root) {
    for (const element of this.active.keys()) if (root.contains(element)) this.cancel(element);
  }

  cancelAll() { for (const element of this.active.keys()) this.cancel(element); }

  reveal(element, name = 'reveal', delay = 0) {
    return this.play(element, [{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'translateY(0)' }], { name, delay });
  }

  stagger(elements, name = 'stagger') {
    [...elements].forEach((element, index) => this.reveal(element, name, Math.min(index * 45, 135)));
  }
}
